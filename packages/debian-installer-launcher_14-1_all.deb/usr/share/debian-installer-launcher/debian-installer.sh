#!/bin/sh

set -e

in_image () {
	chroot /lib/live/installer /usr/bin/env -i LIVE_INSTALLER_MODE=1 DEBIAN_FRONTEND=$DI_FRONTEND DISPLAY=:0 TERM=$TERM $CMDLINE $@
}

CMDLINE=
for parameter in $(cat /proc/cmdline); do
	if echo $parameter | grep '='; then
		CMDLINE="$CMDLINE $parameter"
	fi
done

# Launching debian-installer
in_image /sbin/debian-installer-startup
in_image /sbin/debian-installer
